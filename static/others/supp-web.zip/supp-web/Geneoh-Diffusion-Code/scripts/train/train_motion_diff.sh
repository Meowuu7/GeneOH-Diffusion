export PYTHONPATH=.

export diff_joint_quants=""
export use_vae=""
export kl_weights=0.000001
export jts_sclae_stra="std"
export train_enc=""
export train_diff=""
export set_attn_to_none="--set_attn_to_none"
export use_ours_transformer_enc="--use_ours_transformer_enc"
export not_load_opt="--not_load_opt"
export resume_diff=""
export const_noise=""
export use_sigmoid="--use_sigmoid"
export wo_e_normalization="--wo_e_normalization"
export wo_rel_normalization="--wo_rel_normalization"
export use_dec_rel_v2="--use_dec_rel_v2"
export pred_basejtsrel_avgjts="--pred_basejtsrel_avgjts"
export without_dec_pos_emb="--without_dec_pos_emb"
export single_frame_noise=""
export not_cond_base="--not_cond_base"
export not_pred_avg_jts="--not_pred_avg_jts"
export latent_dim=512
export diff_spatial="--diff_spatial"
export noise_schedule="linear"
export pred_joints_offset="--pred_joints_offset"
export not_diff_avgjts="--not_diff_avgjts"
export resume_checkpoint="--resume_checkpoint [xxx]"
export cuda_ids=5
export use_anchors=""
export joint_std_v2=""
export joint_std_v3="--joint_std_v3"
export augment="--augment"


##### TRAIN on grab #####
export batch_size=2
export save_interval=5000
export use_anchors="--use_anchors"
export resume_checkpoint="--resume_checkpoint [xxxx]"
export diff_basejtsrel="--diff_basejtsrel"
export diff_realbasejtsrel=""
export use_objbase_v5="--use_objbase_v5"
export v5_in_without_glb="--v5_in_without_glb"
export add_noise_onjts="--add_noise_onjts"
export add_noise_onjts_single="" 
export v5_in_not_base="--v5_in_not_base"
export v5_in_not_base_pos=""
export cuda_ids=2
export cuda_ids=3
export latent_dim=512
export window_size=60
export save_dir="./save/motion_diff_grab_"
export augment="--augment"
##### TRAIN on grab #####


##### TRAIN on ARCTIC #####
export use_arctic="--use_arctic"
export start_idx=100
export use_arti_obj="--use_arti_obj"
export batch_size=1
export diff_basejtsrel="--diff_basejtsrel"
export diff_realbasejtsrel=""
export cuda_ids=6
export resume_checkpoint="--resume_checkpoint [xxx]"
export resume_checkpoint=""
export resume_diff="--resume_diff"
export v5_in_without_glb="--v5_in_without_glb"
export add_noise_onjts="--add_noise_onjts"
export add_noise_onjts_single="" 
export v5_in_not_base="--v5_in_not_base"
export v5_in_not_base_pos=""
export save_dir="./save/motion_diff_arcic_sliced_"
##### TRAIN on ARCTIC #####



export cuda_ids=1



CUDA_VISIBLE_DEVICES=${cuda_ids} python -m train.train_mdm --save_dir ${save_dir} --dataset motion_ours --batch_size ${batch_size} ${unconstrained} --window_size ${window_size} --save_interval ${save_interval}  ${diff_basejtsrel}  ${use_vae} --kl_weights ${kl_weights} --jts_sclae_stra ${jts_sclae_stra} ${use_sigmoid} ${train_enc} ${train_diff}  ${resume_checkpoint} ${without_dec_pos_emb} ${use_ours_transformer_enc} ${not_load_opt} ${resume_diff} ${set_attn_to_none} ${const_noise}  ${wo_e_normalization} ${wo_rel_normalization} ${use_dec_rel_v2} ${pred_basejtsrel_avgjts} ${single_frame_noise} ${not_cond_base} ${not_pred_avg_jts} --latent_dim ${latent_dim} ${diff_spatial} --noise_schedule ${noise_schedule} ${pred_joints_offset} ${not_diff_avgjts} ${joint_std_v2} ${joint_std_v3}  ${diff_realbasejtsrel}  ${use_objbase_v5} ${add_noise_onjts} ${add_noise_onjts_single}  ${v5_in_not_base_pos} ${v5_in_not_base} ${v5_in_without_glb}   ${diff_joint_quants}  ${use_anchors}   ${augment}  ${use_arti_obj}  ${use_arctic} --start_idx=${start_idx} 
