export PYTHONPATH=.

export cuda_ids=6

CUDA_VISIBLE_DEVICES=${cuda_ids} python -m sample.reconstruct_data_bundle_v2

