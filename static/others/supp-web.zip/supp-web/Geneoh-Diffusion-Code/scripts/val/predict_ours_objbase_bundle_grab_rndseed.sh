export PYTHONPATH=.

export use_reverse=""
export scale_obj=1
export use_arctic="--use_arctic"

##### motion diff #####
export start_idx="--start_idx 100"
export predicted_info_fn=""
export diff_hand_params=""
export diff_basejtsrel="--diff_basejtsrel"
export diff_realbasejtsrel=""
export diff_basejtse=""
export diff_realbasejtsrel_to_joints=""
export nn_base_pts=700
export real_basejtsrel_norm_stra="none"
export use_objbase_v5="--use_objbase_v5"
export use_objbase_v6=""
export not_cond_base="--not_cond_base"
export v5_out_not_cond_base="--v5_out_not_cond_base"
export joint_std_v3="--joint_std_v3"
export use_var_sched="--use_var_sched"
export v5_in_without_glb="--v5_in_without_glb" 
export add_noise_onjts="--add_noise_onjts"
export add_noise_onjts_single="" 
export v5_in_not_base="--v5_in_not_base"
export v5_in_not_base_pos=""
export use_objbase_out_v5="--use_objbase_out_v5"
export model_path=[MOTION_MODEL_PATH]
export only_cmb_finger=""
export use_arti_obj=""
export theta_dim=24
export use_t=400

export use_left=""
export test_tag="jts_t_400_arctic_"
##### motion diff #####


##### spatial diff #####
export start_idx="--start_idx 100"
export nn_base_pts=2000
export diff_hand_params=""
export diff_basejtsrel=""
export diff_realbasejtsrel="--diff_realbasejtsrel"
export diff_basejtse=""
export single_seq_path=""
export cad_model_fn=""
export use_arti_obj=""
export model_path=[SPATIAL_MODEL_PATH]
export phy_guided_sampling=""
export use_anchors=""
export test_tag="spatial_res_t_200_"
export use_t=200
##### spatial diff #####



##### temporal diff #####
export start_idx="--start_idx 100"
export nn_base_pts=2000
export diff_hand_params=""
export diff_basejtsrel=""
export diff_realbasejtsrel=""
export diff_basejtse="--diff_basejtse"
export single_seq_path=""
export cad_model_fn=""
export use_arti_obj=""
export model_path=[SPATIAL_MODEL_PATH]
export phy_guided_sampling=""
export use_anchors=""
export test_tag="spatial_res_t_200_"
export use_t=200
##### temporal diff #####

### test on GRAB test set ###
export pert_type="gaussian"
### test on GRAB(Beta) test set ###
export pert_type="beta"

export cuda_ids=0


CUDA_VISIBLE_DEVICES=${cuda_ids} python -m sample.predict_ours_objbase_bundle_ours_rndseed_grab --dataset motion_ours --save_dir ${save_dir} --single_seq_path ${single_seq_path} --window_size ${window_size} ${unconstrained} ${inst_normalization}  --model_path ${model_path} --rep_type ${rep_type} --batch_size=${batch_size}  --denoising_stra ${denoising_stra} ${inter_optim} --seed ${seed} ${diff_jts} ${diff_basejtsrel} ${diff_basejtse}  ${use_sep_models} --jts_sclae_stra ${jts_sclae_stra} ${use_vae} ${use_sigmoid} ${train_enc} ${without_dec_pos_emb} ${pred_diff_noise} ${resume_diff} ${not_load_opt} ${deep_fuse_timeemb}  ${use_ours_transformer_enc} ${const_noise} ${set_attn_to_none} ${rnd_noise} ${wo_e_normalization} ${wo_rel_normalization} ${use_dec_rel_v2} ${pred_basejtsrel_avgjts} ${single_frame_noise} --use_t ${use_t} ${not_add_noise} ${not_cond_base}  ${not_pred_avg_jts} --latent_dim ${latent_dim} ${diff_spatial} --noise_schedule ${noise_schedule} ${pred_joints_offset}  ${not_diff_avgjts}  ${joint_std_v3}  ${joint_std_v2}  ${diff_latents}  ${use_canon_joints} ${use_var_sched} --e_normalization_stra ${e_normalization_stra} --real_basejtsrel_norm_stra ${real_basejtsrel_norm_stra} ${diff_realbasejtsrel}  ${diff_realbasejtsrel_to_joints} ${use_abs_jts_for_encoding} ${use_abs_jts_for_encoding_obj_base} ${use_abs_jts_pos} ${use_objbase_v2} ${use_objbase_out_v3} ${use_objbase_v4} ${use_objbase_out_v4} ${use_objbase_v5} ${use_objbase_out_v5} ${out_objbase_v5_bundle_out} --nn_base_pts ${nn_base_pts} ${add_noise_onjts} ${v5_out_not_cond_base} ${use_objbase_v6} ${add_noise_onjts_single} ${only_cmb_finger} ${use_objbase_v7} ${v5_in_not_base_pos} ${v5_in_not_base} ${v5_in_without_glb}  ${finetune_with_cond} --test_tag ${test_tag} ${finetune_with_cond_rel} ${finetune_with_cond_jtsobj} --sel_basepts_idx ${sel_basepts_idx} ${use_same_noise_for_rep} --pert_type ${pert_type} ${phy_guided_sampling} ${use_anchors} ${use_arti_obj} --theta_dim ${theta_dim} ${start_idx} ${use_reverse} --scale_obj ${scale_obj} ${resplit} ${use_arctic} ${use_left}

